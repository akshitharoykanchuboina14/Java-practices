import java.util.*;
public class ATMPIN
{
	public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    int correctPin= 1234;
	    System.out.print("Enter ATM PIN :");
	    int pin= sc.nextInt();
	    if (pin==correctPin){
	        System.out.println("Access granted");
	    }else{
		System.out.println("Invalid PIN");
	    }
	}
}
