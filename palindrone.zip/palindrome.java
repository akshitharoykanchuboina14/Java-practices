import java.util.*;
public class palindrome
{
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("ENter a string :");
	String str=sc.nextLine();
	String rev="";
	for(int i=str.length()-1; i>=0;i--){
	    rev=rev+str.charAt(i);
	}
	if(str.equals(rev)){
	    System.out.println("palindrone of a string");
	}else {
	    System.out.println("Not a palindrone of a string");
	}
}
}