import java.util.*;
public class Startwith
{
	public static void main(String[] args) {
	    String s="java";
		System.out.println(s.Startwith());
	}
}
