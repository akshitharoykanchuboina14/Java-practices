import java.util.*;
public class Student
{
    String name;
    int id;
   
 public static void main (String[] args) {
    }
    {
		System.out.println("name");
		System.out.println("id");
	}
}
