import java.util.*;
public class Demo
{
	void displaymMsg(){
		System.out.print("This is a method body!");
	}
	 public static void main (String[] args) {
Demo d = new Demo.displayMsg();

	}
}
