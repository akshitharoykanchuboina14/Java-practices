import java.util.*;
public class contains
{
	public static void main(String[] args) {
	    String s="java programming";
		System.out.println(s.contains("programming"));
	}
}
