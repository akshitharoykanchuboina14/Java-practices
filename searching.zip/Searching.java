import java.util.*;
public class Searching
{
	public static void main(String[] args){
	   int[] arr={1,9,7,2,5};
	    int key=9;
	    boolean isFound=false;
	    for(int i=0;i<arr.length;i++){
	        if(arr[i]==key)
	        {
	         	System.out.println("Element Found");
	            isFound=true; 
	         	break;
	        }
	        if(isFound==false)
	        System.out.println("Element not Found");
}
}
}