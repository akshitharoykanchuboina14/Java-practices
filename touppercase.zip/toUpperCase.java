import java.util.*;
public class toUpperCase
{
	public static void main(String[] args) {
	    String s="java";
		System.out.println(s.toUpperCase());
	}
}
