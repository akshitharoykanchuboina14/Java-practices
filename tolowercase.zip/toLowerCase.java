import java.util.*;
public class toLowerCase
{
	public static void main(String[] args) {
	    String s="java";
		System.out.println(s.toLowerCase());
	}
}
